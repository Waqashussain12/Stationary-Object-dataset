# Stationary Object Detector > 2023-11-25 12:51pm
https://universe.roboflow.com/waqas-hussain/stationary-object-detector

Provided by a Roboflow user
License: CC BY 4.0

